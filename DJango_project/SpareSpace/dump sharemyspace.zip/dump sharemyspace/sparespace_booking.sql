CREATE DATABASE  IF NOT EXISTS `sparespace` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sparespace`;
-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: sparespace
-- ------------------------------------------------------
-- Server version	5.5.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking` (
  `bookingid` int(11) NOT NULL AUTO_INCREMENT,
  `roomid` int(11) DEFAULT NULL,
  `tariff` varchar(45) DEFAULT NULL,
  `extraperson` int(11) DEFAULT NULL,
  `checkin` date DEFAULT NULL,
  `checkout` date DEFAULT NULL,
  `bookeremail` varchar(100) DEFAULT NULL,
  `bookeraddress` varchar(200) DEFAULT NULL,
  `bookermobile` varchar(10) DEFAULT NULL,
  `hostid` int(11) DEFAULT NULL,
  `totalbill` float DEFAULT NULL,
  `dateofbooking` date DEFAULT NULL,
  `paymentmode` varchar(45) DEFAULT NULL,
  `paymentstatus` varchar(50) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bookingid`),
  KEY `rid` (`roomid`),
  KEY `bemail` (`bookeremail`),
  KEY `hidfk` (`hostid`),
  CONSTRAINT `bemail` FOREIGN KEY (`bookeremail`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `hidfk` FOREIGN KEY (`hostid`) REFERENCES `host` (`hid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rid` FOREIGN KEY (`roomid`) REFERENCES `rooms` (`roomid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (10,56,'single',0,'2019-11-14','2019-11-15','hundal.anmol96@gmail.com','amritsar','9592231891',3,283,'2019-11-14','online','success','pending'),(11,38,'single',1,'2019-11-16','2019-11-19','hundal.anmol96@gmail.com','amritsar','9592231891',5,0,'2019-11-16','Cash','pending','pending'),(12,70,'single',0,'2019-11-18','2019-11-19','ayushi.dhir95@gmail.com','amritsar','8427543923',2,267,'2019-11-18','online','success','pending');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-23 13:32:52
