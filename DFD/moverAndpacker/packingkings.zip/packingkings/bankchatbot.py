import json
from chatterbot.ext.django_chatterbot import settings
from django.views.generic.base import TemplateView
from django.views.generic import View
from django.http import JsonResponse

from django.core.files.storage import *
from django.http import JsonResponse
from django.shortcuts import *
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
# Create a new chat bot named Charlie
chatbot3 = ChatBot("Final Chatbot", read_only=True)
chatbot3.storage.drop()
trainer2 = ListTrainer(chatbot3)

trainer2.train('./my_export.json')
trainer2.train([
"Hi",
"Hello how can i  help you",
])
trainer2.train([
"Hello",
"Hello how can i  help you",
])
trainer2.train([
"Any one there",
"Hello how can i  help you",
])
trainer2.train([
"",
"Do you want to open an Account",
])
trainer2.train([
"Current Account",
"Do you want to open an Account",
])

trainer2.train([
"Fixed Deposit",
"Do you want to open an Account",
])

trainer2.train([
"Credit Card",
"Do you want to open an Account",
])


trainer2.train([
"Yes",
"Your request is received.Thank You.",
])
trainer2.train([
"No",
"Your request is cancelled.",
])
trainer2.train([
"loan",
"Do you want to apply for loan?"
])
trainer2.train([
"yes",
"what kind of loan?"
])



def chatwindow(request):
    return render(request,'chatwindow.html')
def chat(request):
    return render(request,'chat.html')
def sendmessage(request):
    message = request.GET['message']
    print('fffffffffff',message)
    # Get a response to the input text 'I would like to book a flight.'
    response = chatbot3.get_response(message)
    print(response)
    return  HttpResponse(response)
class ChatterBotApiView(View):
    """
    Provide an API endpoint to interact with ChatterBot.
    """

    chatterbot = ChatBot(**settings.CHATTERBOT)

    def post(self, request, *args, **kwargs):
        """
        Return a response to the statement in the posted data.

        * The JSON data should contain a 'text' attribute.
        """
        input_data = json.loads(request.body.decode('utf-8'))

        if 'text' not in input_data:
            return JsonResponse({
                'text': [
                    'The attribute "text" is required.'
                ]
            }, status=400)

        response = self.chatterbot.get_response(input_data)

        response_data = response.serialize()

        return JsonResponse(response_data, status=200)

    def get(self, request, *args, **kwargs):
        """
        Return data corresponding to the current conversation.
        """
        return JsonResponse({
            'name': self.chatterbot.name
        })

